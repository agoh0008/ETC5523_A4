library(testthat)

# Sample data frame for testing
sample_data <- data.frame(
  Major_category = c("Engineering", "Arts", "Business"),
  Women = c(100, 150, 200),
  Men = c(300, 250, 400)
)

test_that("calc_female_grad_percent function calculates correctly", {

  # Test case 1: Calculate proportion of female graduates for Engineering majors
  result1 <- calc_female_grad_percent(sample_data, "Engineering")
  expect_equal(result1, 25.0)  # Expected result for Engineering: (100 / (100 + 300)) * 100 = 25.0

  # Test case 2: Calculate proportion of female graduates for Business majors
  result2 <- calc_female_grad_percent(sample_data, "Business")
  expect_equal(result2, 33.3)  # Expected result for Business: (200 / (200 + 400)) * 100 = 33.3

  # Test case 3: Calculate proportion of female graduates for a non-existent category
  result3 <- calc_female_grad_percent(sample_data, "Health")  # Health category doesn't exist in the sample_data
  expect_true(is.na(result3))   # Expected result for a non-existent category: NA

  # Test case 4: Calculate proportion of female graduates with no data
  missing_data <- data.frame(
    Major_category = c("Engineering", "Arts", "Business"),
    Women = c(0, 150, 200),
    Men = c(100, 250, 400)
  )
  result4 <- calc_female_grad_percent(missing_data, "Engineering")  # No data in the data frame
  expect_equal(result4, 0)  # Expected result with no data: 0

  # Test case 5: Calculate proportion of female graduates with zero total graduates
  zero_data <- data.frame(
    Major_category = c("Engineering"),
    Women = c(0),
    Men = c(0)
  )
  result5 <- calc_female_grad_percent(zero_data, "Engineering")  # Total graduates (women + men) is zero
  expect_equal(result5, 0)  # Expected result with zero total graduates: 0
})

  # Test case 6: Calculate proportion of female graduates with invalid major_category input
  result6 <- calc_female_grad_percent(sample_data, "ENGINEERING")
  expect_true(is.na(result6))  # Expected result with invalid input: NA

