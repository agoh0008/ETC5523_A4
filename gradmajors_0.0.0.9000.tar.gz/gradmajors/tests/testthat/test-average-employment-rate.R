library(testthat)

test_that("average_employment_rate function calculates correctly", {
  sample_data <- data.frame(
    Major_category = c("Engineering", "Arts", "Business"),
    Unemployment_rate = c(0.05, 0.1, 0.08)
  )

  # Test case 1: Calculate average employment rate for Engineering majors
  result1 <- average_employment_rate(sample_data, "Engineering")
  expect_equal(result1, 95)  # Expected result for Engineering: 100 - (0.05 * 100) = 95

  # Test case 2: Calculate average employment rate for Business majors
  result2 <- average_employment_rate(sample_data, "Business")
  expect_equal(result2, 92)  # Expected result for Business: 100 - (0.08 * 100) = 92

  # Test case 3: Calculate average employment rate for a non-existent category
  result3 <- average_employment_rate(sample_data, "Health")  # Health category doesn't exist in the sample_data
  expect_true(is.na(result3))  # Expected result for a non-existent category: NA

  # Test case 4: Calculate average employment rate with missing/unavailable data
  sample_data_missing <- data.frame(
    Major_category = c("Engineering", "Arts", "Business"),
    Unemployment_rate = c(0.05, NA, 0.08)
  )
  result4 <- average_employment_rate(sample_data_missing, "Arts")
  expect_true(is.na(result4))  # Expected result with missing data: NA
})
