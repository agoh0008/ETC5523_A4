#' @name average_employment_rate
#' @title Calculate Average Employment Rate for a Major Category
#' @description
#' This function calculates the average employment rate for a specific major category.
#' The employment rate is calculated as 100% minus the unemployment rate.
#'
#' @param data A data frame containing the dataset
#' @param major_category The major category for which you want to calculate the average employment rate.
#'
#' @return The average employment rate rounded to one decimal place.
#'
#' @examples
#' average_employment_rate(recent_grads, "Engineering")
#'
#' @import dplyr
#'
#' @export


library(dplyr)

average_employment_rate <- function(data, major_category) {
  filtered_data <- data %>%
    filter(Major_category == major_category)

  if (missing(major_category) || is.null(major_category) || major_category == "") {
    return(NA_character_)
  }

  if (nrow(filtered_data) == 0) {
    return(NA_character_)
  }

  if (any(is.na(filtered_data$Unemployment_rate)) ||
      any(filtered_data$Unemployment_rate == 0)) {
    return(NA_character_)
  }

  avg_employment_rate <- round(mean(1 - filtered_data$Unemployment_rate)*100, 1)
  return(avg_employment_rate)
}

