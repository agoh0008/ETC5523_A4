#' Recent College Graduates Data
#'
#' This data frame contains information about recent college graduates
#' and their college majors. It provides data on various attributes of
#' college majors, as well as the outcomes of recent graduates in terms
#' of employment, earnings, and more.
#'
#' @format A data frame with 173 rows and 21 columns.
#'
#' @usage data(recent_grads)
#'
#' @name recent_grads
#' @docType data
#' @keywords datasets
#' @source The data was obtained from the TidyTuesday project on GitHub.
#'   You can find it here: https://github.com/rfordatascience/tidytuesday/blob/master/data/2018/2018-10-16/recent-grads.csv
#'
#' @examples
#' # Load the recent_grads data
#' data(recent_grads)
#'
#' # View the first few rows of the data
#' head(recent_grads)
#'
#' @seealso
#' \code{recent_grads_vignette()} for more details on how to use this dataset.
#' @references
#' You can find additional information about this dataset in the package vignette.
#' "recent_grads" <- readRDS(system.file("extdata", "recent_grads.rds", package = "gradmajors"))

#' @section Column Descriptions:
#'
#' \describe{
#'   \item{Rank}{Rank by median earnings}
#'   \item{Major_code}{Major code}
#'   \item{Major}{Major description}
#'   \item{Major_category}{Category of major}
#'   \item{Total}{Total number of people with major}
#'   \item{Sample_size}{Sample size (unweighted) of full-time, year-round ONLY (used for earnings)}
#'   \item{Men}{Male graduates}
#'   \item{Women}{Female graduates}
#'   \item{Sharewomen}{Share of women (as a proportion of total)}
#'   \item{Employed}{Number employed}
#'   \item{Full_time}{Employed 35 hours or more}
#'   \item{Part_time}{Employed less than 35 hours}
#'   \item{Full_time_year_round}{Employed at least 50 weeks (WKW == 1) and at least 35 hours (WKHP >= 35)}
#'   \item{Unemployed}{Number unemployed (ESR == 3)}
#'   \item{Unemployment_rate}{Unemployment rate (unemployed / (unemployed + employed))}
#'   \item{Median}{Median earnings of full-time, year-round workers}
#'   \item{P25th}{25th of percentile earnings}
#'   \item{P75th}{75th of percentile earnings}
#'   \item{College_jobs}{Number with job requiring a college degree}
#'   \item{Non_college_jobs}{Number with job not requiring a college degree}
#'   \item{Low_wage_jobs}{Number in low-wage service jobs}
#' }


