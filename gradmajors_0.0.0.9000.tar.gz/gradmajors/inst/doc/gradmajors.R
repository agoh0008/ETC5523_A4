## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message = FALSE, warning = FALSE----------------------------------
library(gradmajors)
library(tidyverse)


## -----------------------------------------------------------------------------
head(recent_grads)


## -----------------------------------------------------------------------------
average_employment_rate(recent_grads, "Engineering")

## -----------------------------------------------------------------------------
calc_female_grad_percent(recent_grads, "Business")

## ----fig.width= 8, fig.height = 4---------------------------------------------
generate_gender_representation_plot("Arts", "All", recent_grads)

## ----fig.width= 8, fig.height = 4---------------------------------------------
generate_gender_representation_plot("Engineering", c("Architecture", "Civil Engineering"), recent_grads)

